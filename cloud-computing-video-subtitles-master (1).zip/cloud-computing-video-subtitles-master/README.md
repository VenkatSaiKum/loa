# Legendas Tubarão

Project developed for the  Cloud Computing class

![project architecture](misc/architecture.svg)

The instructions to use the project are available on [docs](docs).
